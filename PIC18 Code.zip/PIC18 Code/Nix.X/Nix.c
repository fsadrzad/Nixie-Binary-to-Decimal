//Include all libraries
#include <xc.h>
#include <stdio.h>
#include <stdlib.h>
#include <plib.h>
#include "XC8.h"

//Indicate the presence of a delay function at the bottom of the code
void d (void);

void main(void) {
    
  //Input Variables 
  int a, b, c, e, f, g, h; //input reading
  //Assembled input, The ones 
  int full, ones, tens;
  a = 0; b = 0; c = 0; e = 0; f = 0; g = 0; ones = 0; tens = 0;
  //Configure the oscillator select and mode
  OSCCON = 0x76; 
  //Make all ports outputs at first
  TRISC = 0x00;
  TRISB = 0x00;
  TRISA = 0x00;
  //Select the desired inputs
  TRISBbits.RB5 = 1; // input bit0
  TRISC = 0b11000111; // input bit 1,2,3,4,5
  TRISAbits.RA6 = 1; //input bit 6
  
  
    //Run Forever
    while (1)
    {
        // Re-zero the assembled input for recalculation
        full = 0; 
        //Rezero all the outputs
        LATB = 0b00000000;
        LATC = 0b00000000;
        LATA = 0b00000000;
        //For assembling the inputs we only mask the first bit and then we shift according to least to most significant bit
        a = ((~((int)PORTBbits.RB5)) & 0b0000000000000001);         //input 0
        b = ((~((int)PORTCbits.RC7)) & 0b0000000000000001) << 1;    //input 1
        c = ((~((int)PORTCbits.RC6)) & 0b0000000000000001) << 2;    //input 2
        e = ((~((int)PORTCbits.RC2)) & 0b0000000000000001) << 3;    //input 3
        f = ((~((int)PORTCbits.RC1)) & 0b0000000000000001) << 4;    //input 4
        g = ((~((int)PORTCbits.RC0)) & 0b0000000000000001) << 5;    //input 5
        h = ((~((int)PORTAbits.RA6)) & 0b0000000000000001) << 6;    //input 6
        //Assemble all the input bits into full
        full = (a + b + c);
        if (e) full = full + 8;
        if (f) full = full + 16;
        if (g) full = full + 32;
        if (h) full = full + 64;
        
        //Select the ones tube
        LATAbits.LA5 = 1;
//        if (full == 3) LATBbits.LATB0 = 1; //integer 1 = 2^0
        //Isolate the ones decimal value from the fully assembled input
        ones = full%10;
        //Relay the right digit based on the ones variable
        if (ones == 0) LATBbits.LATB0 = 1; else
            if (ones == 1) LATBbits.LATB1 = 1; else
                if (ones == 2)  LATBbits.LATB2 = 1; else
                    if (ones == 3) LATBbits.LATB3 = 1; else
                        if (ones == 4) LATBbits.LATB4 = 1; else
                            if (ones == 5) LATAbits.LATA2 = 1; else
                                if (ones == 6) LATBbits.LATB6 = 1; else
                                    if (ones == 7) LATBbits.LATB7 = 1; else
                                        if (ones == 8) LATAbits.LATA0 = 1; //else
                                            if (ones == 9)  LATAbits.LATA1 = 1; else {d();}
                                    d(); //give it a delay
        //Re-zero all latches for the display of the tens digit
        LATB = 0b00000000;
        LATC = 0b00000000;
        LATA = 0b00000000;
        //Turn off the ones digit Nixie selector
        LATAbits.LA5 = 0;
        //Isolate the tens variable from the fully assembled input
        tens = full / 10;
        //Turn on the tens digit Nixie selector
        LATAbits.LA3 = 1;
        //Make sure the tens value is 0-9. 
        if (tens < 10)
        {
            //Relay the right digit selector according to the tens value
            if (tens == 0) LATBbits.LATB0 = 1; else
                if (tens == 1) LATBbits.LATB1 = 1; else
                    if (tens == 2)  LATBbits.LATB2 = 1; else
                        if (tens == 3) LATBbits.LATB3 = 1; else
                            if (tens == 4) LATBbits.LATB4 = 1; else
                                if (tens == 5) LATAbits.LATA2 = 1; else
                                    if (tens == 6) LATBbits.LATB6 = 1; else
                                        if (tens == 7) LATBbits.LATB7 = 1; else
                                            if (tens == 8) LATAbits.LATA0 = 1; //else
                                                if (tens == 9)  LATAbits.LATA1 = 1; else {d();}
                                    d();
        } else { LATBbits.LATB0 = 1; d();d();} //if tens is larger than 10 display zero on the Nixie
        d();d(); //Some delay
        //Turn off the Nixie tens tube selector
        LATAbits.LA3 = 0;
//        {
//            //B0-B1-B2-B3-B4-A2-B6-B7-A0-A1
//            //0 -1 -2 -3 -4 -5 -6 -7 -8 -9
//        LATBbits.LATB0 = 1;
//        d();d();
//        LATBbits.LATB0 = 0;
//        LATBbits.LATB1 = 1;
//        d();d();
//        LATBbits.LATB1 = 0;
//        LATBbits.LATB2 = 1;
//        d();d();
//        LATBbits.LATB2 = 0;
//        LATBbits.LATB3 = 1;
//        d();d();
//        LATBbits.LATB3 = 0;
//        LATBbits.LATB4 = 1;
//        d();d();
//        LATBbits.LATB4 = 0;
//        LATAbits.LATA2 = 1;
//        d();d();
//        LATAbits.LATA2 = 0;
//        LATBbits.LATB6 = 1;
//        d();d();
//        LATBbits.LATB6 = 0;
//        LATBbits.LATB7 = 1;
//        d();d();
//        LATBbits.LATB7 = 0;
//        LATAbits.LATA0 = 1;
//        d();d();
//        LATAbits.LATA0 = 0;
//        LATAbits.LATA1 = 1;
//        d();d();
//        LATAbits.LATA1 = 0;
//        LATAbits.LATA3 = 1;
//        d();d();
//        LATAbits.LATA3 = 0;
//        LATAbits.LATA5 = 1;
//        d();d();
//        LATAbits.LATA5 = 0;
//        }
    }
}

void d (void) //Wait function
{
    int c = 0;
    for (c = 0; c < 100; c++)
    {
        //wait
    }
}